export default function hola() {
    return (
        <div>
            <h2>Hola mundo!</h2>
            <Boton></Boton>
        </div>
    );
}