export default function Boton() {
    return <button>Hola soy boton</button>
}