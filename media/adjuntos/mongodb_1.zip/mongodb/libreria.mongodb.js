use('libreria');
db.dropDatabase();

db.getCollection('libros').insertMany(
    [
        {
            titulo: 'El Silmarillion',
            autor: 'JRR Tolkien',
            precio: 15000,
            stock: 15
        },
        {
            titulo: 'Crimen y Castigo',
            autor: 'Fiodor Dostoiesvki',
            precio: 12000,
            stock: 11
        },
        {
            titulo: 'Sombras contra el muro',
            autor: 'Manuel Rojas',
            precio: 5600,
            stock: 22
        },
        {
            titulo: 'Las dos torres',
            autor: 'JRR Tolkien',
            precio: 13700,
            stock: 30
        },
        {
            titulo: 'El proceso',
            autor: 'Franz Kafka',
            precio: 9700,
            stock: 21
        },
        {
            titulo: 'Canción de Hielo y Fuego',
            autor: 'George HR Martin',
            precio: 31000,
            stock: 6
        }
    ]
);


//agregar un campo a todos los documentos
db.getCollection('libros').updateMany(
    {},
    {$set:{editorial: ''}},
    {upsert:false}
);

db.getCollection('libros').updateMany(
    {},
    {$set:{año: ''}},
    {upsert:false}
);

db.getCollection("libros").find()

db.getCollection('libros').updateOne(
    {titulo:{$eq:'El Silmarillion'}}, 
    {$set:{editorial: 'Minotauro'}},
    {upsert:false}
);//Se agrega el dato

db.getCollection('libros').updateOne(
    {titulo:{$eq:'El Silmarillion'}}, 
    {$set:{año:2006}},
    {upsert:false}
);//Se agrega el dato

db.getCollection('libros').updateOne(
    {titulo:{$eq:'Crimen y Castigo'}}, 
    {$set:{editorial: 'Kiev'}},
    {upsert:false}
);//Se agrega el dato

db.getCollection('libros').updateOne(
    {titulo:{$eq:'Crimen y Castigo'}}, 
    {$set:{año:2010}},
    {upsert:false}
);//Se agrega el dato

db.getCollection('libros').updateOne(
    {titulo:{$eq:'Sombras contra el muro'}}, 
    {$set:{editorial: 'Alfaguara'}},
    {upsert:false}
);//Se agrega el dato

db.getCollection('libros').updateOne(
    {titulo:{$eq:'Sombras contra el muro'}}, 
    {$set:{año:2015}},
    {upsert:false}
);//Se agrega el dato

db.getCollection('libros').updateOne(
    {titulo:{$eq:'Las dos torres'}}, 
    {$set:{editorial: 'Minotauro'}},
    {upsert:false}
);//Se agrega el dato

db.getCollection('libros').updateOne(
    {titulo:{$eq:'Las dos torres'}}, 
    {$set:{año:2002}},
    {upsert:false}
);//Se agrega el dato

db.getCollection('libros').updateOne(
    {titulo:{$eq:'El proceso'}}, 
    {$set:{editorial: 'Caja negra', año:2013}},
    {upsert:false}
);//Se agrega el dato

db.getCollection('libros').updateOne(
    {titulo:{$eq:'Canción de Hielo y Fuego'}}, 
    {$set:{editorial: 'Fuego', año:2003}},
    {upsert:false}
);//Se agrega el dato

db.getCollection("libros").find()