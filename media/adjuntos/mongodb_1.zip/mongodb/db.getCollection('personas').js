db.getCollection('personas').findOne({ rut_persona: '1-9' });

const persona1 = db.getCollection('personas').findOne(
    { rut_persona: '1-9' }
);


console.log(persona1)

console.log(persona1.nombre_persona)

const persona2 = {
    rut_persona: '3-7',
    nombre_persona: 'Armando',
    edad_persona: 25
};

const result = db.getCollection('personas').insertOne(persona2);

console.log(result);

console.log(result.insertedId);

db.getCollection('personas').findOne({
    _id:result.insertedId
});