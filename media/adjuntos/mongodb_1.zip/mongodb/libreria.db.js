use('libreria');

db.getCollection('libros').insertMany(
    [
        {
            titulo: 'El Silmarillion',
            autor: 'JRR Tolkien',
            precio: 15000,
            stock: 15
        },
        {
            titulo: 'Crimen y Castigo',
            autor: 'Fiodor Dostoiesvki',
            precio: 12000,
            stock: 11
        },
        {
            titulo: 'Sombras contra el muro',
            autor: 'Manuel Rojas',
            precio: 5600,
            stock: 22
        },
        {
            titulo: 'Las dos torres',
            autor: 'JRR Tolkien',
            precio: 13700,
            stock: 30
        },
        {
            titulo: 'El proceso',
            autor: 'Franz Kafka',
            precio: 9700,
            stock: 21
        },
        {
            titulo: 'Canción de Hielo y Fuego',
            autor: 'George HR Martin',
            precio: 31000,
            stock: 6
        }
    ]
);