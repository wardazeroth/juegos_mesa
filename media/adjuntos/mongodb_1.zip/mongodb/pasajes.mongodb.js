// db.getCollection('pasajes').insertMany(
//     [
//         {
//         cod_pasaje:22,
//         rut_pasajero: 27096667,
//         origen: "Puerto Montt",
//         destino: "Valdivia",
//         num_asiento: 11,
//         valor: 5600
    
//     },
//     {
//         cod_pasaje:14,
//         rut_pasajero: 77128200,
//         origen: "Puerto Varas",
//         destino: "Chiloé",
//         num_asiento: 11,
//         valor: 5600
//     }
// ]
// );

// db.getCollection('pasajes').insertMany(
//     [
//         {
//         cod_pasaje:17,
//         rut_pasajero: 83836667,
//         origen: "Talca",
//         destino: "Arica",
//         num_asiento: 13,
//         valor: 15500
    
//     },
//     {
//         cod_pasaje: 3,
//         rut_pasajero: 179928200,
//         origen: "Viña del Mar",
//         destino: "Valparaíso",
//         num_asiento: 17,
//         valor: 12300
//     }
// ]
// );

db.getCollection('pasajes').findOne({
    destino: "Arica"
});

db.getCollection('pasajes').find({
    valor: {$lt:10000}
})

const valdivia = db.getCollection('pasajes').findOne({
     _id: ObjectId("680a3d6d7353e64b280f258d") 
} 
);

console.log(valdivia.origen)
console.log(valdivia.destino)


db.getCollection('pasajes').find()