const persona= db.getCollection('personas').findOne({ rut_persona: '1-9'});

console.log(persona);

persona.nombre_persona = 'Juanito';
console.log(persona);

db.getCollection('personas').updateOne(
    { rut_persona: {$eq:'1-9'}}, // Criterio de búsqueda 
    { $set:{nombre_persona: 'Juanito'} } //Campo a modificar
);

db.getCollection('personas').findOne({ rut_persona: '1-9'});

db.getCollection('personas').find({edad_persona: { $gte:30 }})

//EN base a la colección 'pasajes', 
//1 .Busque los pasajes cuyo destino es (...)
//2. Busque todos los pasajes con un valor inferior a 5000
//3. Busque un pasaje usando un ObjectId específico. Muestre el origen y el destino por la consola