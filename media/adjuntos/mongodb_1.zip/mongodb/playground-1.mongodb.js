
db.getCollection('personas').insertMany(
[
    {
        
        rut_persona:'1-9',
        nombre_persona: 'Juan',
        edad_persona: 30
    },
    {
        rut_persona:'2-8',
        nombre_persona: 'Luisa',
        edad_persona: 21
    }
]
);

db.getCollection('personas').find()

db.getCollection('personas').updateOne(
    {rut_persona:{$eq:'1-9'}},
    {$set:{edad_persona:31}}
);
//Se muestra el documento modiificado
db.getCollection('personas').findOne({
    rut_persona:{$eq:'1-9'}
})

//Agregar un campo a un documento
db.getCollection('personas').updateOne(
    {rut_persona:{$eq:'1-2'}},
    {$set:{fono:'97868499'}},
    {upsert:false}
);

//Se muestra el documento modificado
db.getCollection('personas').findOne({rut_persona:{$eq:'1-9'}})

db.getCollection('personas').findOne(
    {rut_persona:'1-2'}
)


db.getCollection('personas').updateOne(
    {rut_persona:{$eq:'16-6'}}, // RUT no existe
    {$set:{fono:'97868499'}},
    {upsert:true}
);//Se agrega el dato

//agregar un campo a todos los documentos
db.getCollection('personas').updateMany(
    {},
    {$set:{direccion: ''}},
    {upsert:false}
);

//Se muestran los documentos modificados:
db.getCollection('personas').find()

//Agregar bono a todos los documentos que coincidan con el criterio
db.getCollection('personas').updateMany(
    {edad_persona:{$gte:25}},
    {$set:{bono:25000}},
    {upsert:false}
);

//Se muestran los documento modificados
db.getCollection('personas').find();

